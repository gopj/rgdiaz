<tr>
	<td valign="top" colspan="2">
		<div class="wm_information_com">
			<?php echo CApi::I18N('ADMIN_PANEL/HELPDESK_SOCIAL_DESK'); ?>
		</div>
	</td>
</tr>